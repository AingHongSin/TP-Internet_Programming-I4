import Group from './Group';
export var mainGroup = new Group();
//# sourceMappingURL=mainGroup.js.map