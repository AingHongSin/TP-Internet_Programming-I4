/**
 * Utils
 */
export default class Sequence {
    private static _nextId;
    static nextId(): number;
}
