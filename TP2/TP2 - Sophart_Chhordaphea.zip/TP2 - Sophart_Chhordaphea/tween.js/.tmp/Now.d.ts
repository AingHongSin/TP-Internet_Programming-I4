declare let now: () => number;
export default now;
