import Group from './Group';
export declare const mainGroup: Group;
