const {tests} = require('../../.tmp/tests.cjs.js')
module.exports = {tween: tests}
