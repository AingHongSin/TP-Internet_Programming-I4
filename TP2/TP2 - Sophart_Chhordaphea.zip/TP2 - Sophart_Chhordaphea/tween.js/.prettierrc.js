module.exports = {
	arrowParens: 'avoid',
	bracketSpacing: false,
	printWidth: 120,
	semi: false,
	singleQuote: true,
	trailingComma: 'all',
	useTabs: true,
}
